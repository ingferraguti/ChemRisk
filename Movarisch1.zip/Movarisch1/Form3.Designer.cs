﻿namespace Movarisch1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel4 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.treeView2 = new System.Windows.Forms.TreeView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button19 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.treeView2);
            this.panel4.Location = new System.Drawing.Point(12, 28);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(355, 454);
            this.panel4.TabIndex = 7;
            this.panel4.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(157, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Valutazione guidata:";
            // 
            // treeView2
            // 
            this.treeView2.Location = new System.Drawing.Point(19, 46);
            this.treeView2.Name = "treeView2";
            this.treeView2.Size = new System.Drawing.Size(309, 332);
            this.treeView2.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button19);
            this.panel5.Controls.Add(this.button13);
            this.panel5.Controls.Add(this.button14);
            this.panel5.Controls.Add(this.button15);
            this.panel5.Controls.Add(this.button16);
            this.panel5.Controls.Add(this.button17);
            this.panel5.Controls.Add(this.button18);
            this.panel5.Controls.Add(this.listBox5);
            this.panel5.Controls.Add(this.listBox6);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.checkBox2);
            this.panel5.Controls.Add(this.textBox3);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Location = new System.Drawing.Point(388, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(570, 540);
            this.panel5.TabIndex = 8;
            this.panel5.Visible = false;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(26, 383);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(177, 34);
            this.button19.TabIndex = 15;
            this.button19.Text = "Nuova Sostanza";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(25, 424);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(178, 33);
            this.button13.TabIndex = 14;
            this.button13.Text = "Carica Miscela salvata";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(25, 490);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(126, 35);
            this.button14.TabIndex = 13;
            this.button14.Text = "Abbandona";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(438, 490);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(83, 35);
            this.button15.TabIndex = 12;
            this.button15.Text = "Avanti ->";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(324, 396);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(197, 28);
            this.button16.TabIndex = 11;
            this.button16.Text = "Rimuovi tutto";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(324, 363);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(197, 27);
            this.button17.TabIndex = 10;
            this.button17.Text = "Rimuovi selezionato";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(235, 238);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(57, 44);
            this.button18.TabIndex = 9;
            this.button18.Text = "=>";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 16;
            this.listBox5.Location = new System.Drawing.Point(324, 161);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(197, 196);
            this.listBox5.TabIndex = 8;
            // 
            // listBox6
            // 
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 16;
            this.listBox6.Location = new System.Drawing.Point(25, 161);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(178, 196);
            this.listBox6.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 141);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "Sostanze Pericolose:";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(278, 113);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(210, 21);
            this.checkBox2.TabIndex = 5;
            this.checkBox2.Text = "Salva nel databse personale";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(278, 85);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(243, 22);
            this.textBox3.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(229, 17);
            this.label10.TabIndex = 3;
            this.label10.Text = "Numero identificativo (CAS, IUPAC)";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(278, 57);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(243, 22);
            this.textBox4.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Nome:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Miscela Pericolosa";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 763);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TreeView treeView2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}