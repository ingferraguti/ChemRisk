﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movarisch1
{
    public partial class ValutazioneGuidata : Form
    {
        public ValutazioneGuidata()
        {
            InitializeComponent();
        }

        private void ValutazioneGuidata_Load(object sender, EventArgs e)
        {
            //RiepilogoValutazioneGuidata riepilogo = new RiepilogoValutazioneGuidata();
            //riepilogo.MdiParent = this;
            //riepilogo.Show();
        }
    }
}
